#!/usr/bin/env bash

YAKE_PORT=5000
YAKE_IMAGE="liaad/yake"
YAKE_SERVER_IMAGE="liaad/yake-server"
TAG="latest"
